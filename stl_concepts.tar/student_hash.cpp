/* --------------------------------------------------
*  Name: YongQuan Zhang
*  ID: 1515873
*  CMPUT 275, Winter 2020
*  Weekly Exercise #6: STL Concepts
*---------------------------------------------------*/

#include <iostream>
#include <functional>
#include <unordered_set>
#include <algorithm>
#include <string>
using namespace std;

struct StudentRecord {
	string name;
	int id, grade;

	bool operator==(const StudentRecord &obj) const
	{
		// Since ID is unique so we only need to compare
		// ID.
		return(id == obj.id);
	}
};
namespace std {
	template<>
	struct hash<StudentRecord>
		{
		size_t operator()(const StudentRecord &obj)const
		{
			// Hash will depends on ID since ID is unique but
			// name and grade may repeat.
			return(std::hash<int>()(obj.id));
		}
	};
}

int main() {
	unordered_set <StudentRecord> table;
	char instruction;
	char Q_instruc;
	bool query = true;
	string name;
	int id,grade;
	while(query){
		cin >> instruction;
		if(instruction == 'I'){
			cin >> name >> id >> grade;
			// Create an iterator to use the find function.
			// Because this will make sure the the insertion
			// step run in constant time.
			auto itr = table.find(StudentRecord{"", id, 0});
			if(itr == table.end()){
				table.insert(StudentRecord{name,id,grade});
			}
			else{
				cout << "Error: Cannot insert duplicate ID" << endl;
			}
		}
		else if(instruction == 'R'){
			cin >> id;
			auto itr = table.find(StudentRecord{"", id, 0});
			if(itr != table.end()){
				table.erase({"", id, 0});
			}
			else{
				cout << "Error: Cannot remove non-existent ID" << endl;
			}
		}
		else if(instruction == 'Q'){
			// "flag = true" represents we did not find the input
			// id,name or grade in the unordered_set.
			bool flag = true;
			cin >> Q_instruc;
			if(Q_instruc == 'i'){
				cin >> id;
				auto itr = table.find(StudentRecord{"", id, 0});
				if(itr != table.end()){
					cout <<"Name: "<<(*itr).name <<", ID: "
					<< (*itr).id <<", Grade: "<< (*itr).grade << endl;
				}
				else{
					cout << "Error: No matches found" << endl;
				}
			}
			else if(Q_instruc == 'n'){
				cin >> name;
				for(auto ss: table){
					if(ss.name == name){
						cout <<"Name: "<<ss.name <<", ID: "
						<< ss.id <<", Grade: "<< ss.grade << endl;
						flag = false;
					}
				}
				if(flag){
					cout << "Error: No matches found" << endl;
				}
			}
			else if(Q_instruc == 'g'){
				cin >> grade;
				for(auto ss: table){
					if(ss.grade == grade){
						cout <<"Name: "<<ss.name <<", ID: "
						<< ss.id <<", Grade: "<< ss.grade << endl;
						flag = false;
					}
				}
				if(flag){
					cout << "Error: No matches found" << endl;
				}		
			}						
		}
		else if(instruction == 'S'){
			query = false;
		}
	}
	return 0;
}
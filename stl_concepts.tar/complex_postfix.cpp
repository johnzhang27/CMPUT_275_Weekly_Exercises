/* --------------------------------------------------
*  Name: YongQuan Zhang
*  ID: 1515873
*  CMPUT 275, Winter 2020
*  Weekly Exercise #6: STL Concepts
*---------------------------------------------------*/
#include <utility>
#include <stack>
#include <iostream>
using namespace std;

pair<long long,long long> binaryOperator(char secondinstruc, stack<pair<long long,long long>> s){
	/* This function is for all binary operations.

		Args:
		secondinstruc, a second instruction which will be
		one of {+,-,*}.
		stack<pair<long long,long long>> s, a stack which contains
		pairs.

		Return: 
		paircombined, a pair<long long,long long> variable
		which stores the result after the binary instruction.
	*/
	pair<long long,long long> pair1;
	pair<long long,long long> pair2;
	pair<long long,long long> paircombined;
	if(secondinstruc == '+'){
		pair2 = s.top();
		s.pop();
		pair1 = s.top();
		paircombined.first = pair1.first + pair2.first;
		paircombined.second = pair1.second + pair2.second;
	}
	else if(secondinstruc == '-'){
		pair2 = s.top();
		s.pop();
		pair1 = s.top();
		paircombined.first = pair1.first - pair2.first;
		paircombined.second = pair1.second - pair2.second;
	}
	else if(secondinstruc == '*'){
		pair2 = s.top();
		s.pop();
		pair1 = s.top();
		paircombined.first = pair1.first * pair2.first 
							- pair1.second * pair2.second;
		paircombined.second = pair1.first * pair2.second 
							+ pair1.second * pair2.first;
		
	}
	return paircombined;
}
pair<long long,long long> unaryOperator(char secondinstruc,stack<pair<long long,long long>> s){
	/* This function is for all unary operations.

		Args:
		secondinstruc, a second instruction which will be
		one of {-,c}.
		stack<pair<long long,long long>> s, a stack which contains
		pairs.

		Return: 
		paircombined, a pair<long long,long long> variable
		which stores the result after the binary instruction.
	*/	
	pair<long long,long long> pair1;
	pair<long long,long long> pair2;
	pair<long long,long long> paircombined;
	if(secondinstruc == '-'){
		pair1 = s.top();		
		paircombined.first = 0 - pair1.first;
		paircombined.second = 0 - pair1.second;
	}
	else if(secondinstruc == 'c'){
		pair1 = s.top();
		paircombined.first = pair1.first;
		paircombined.second = 0 - pair1.second;		
	}
	return paircombined;
}

int main(){
	stack<pair<long long,long long>> s;
	char instruction;
	char secondinstruc;
	bool process = true;
	long long realnum,imgnum;
	pair<long long,long long> temp;
	while(process){
		cin >> instruction;
		if(instruction == 'V'){
			cin >> realnum >> imgnum;
			s.push(make_pair(realnum,imgnum));
		}
		else if(instruction == 'B'){
			cin >> secondinstruc;
			temp = binaryOperator(secondinstruc,s);
			s.pop();// Remove the previous inputs.
			s.pop();
			s.push(temp);
		}
		else if(instruction == 'U'){
			cin >> secondinstruc;
			temp = unaryOperator(secondinstruc,s);
			s.pop();
			s.push(temp);
		}
		else if(instruction == 'S'){
			process = false;
		}
	}
	pair<long long,long long> ans = s.top();
	cout << ans.first <<" "<< ans.second << endl;
}